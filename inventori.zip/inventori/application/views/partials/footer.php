<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright © <a href="https://www.instagram.com/p/CrqdXh1LVfZpccTYAGZeAuWIU45HyW_MnnzGE00/?igsh=MW1ha2ZzY3I0OGl3OQ==" target="_blank">Melisa Puspita Sari</a></span>
		</div>
	</div>
</footer>